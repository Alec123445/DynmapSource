<?php
        include "core.php";
?>